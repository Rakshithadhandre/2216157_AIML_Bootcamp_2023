#step 1
import sqlite3
#combine step 2 & step 3
"BootCamp2023.db"
conn = sqlite3.connect("BootCamp2023.db")
print(conn)

records=conn.execute("select *from participants")
print(records)
for i in records:
    print(i)
conn.commit()
conn.close()
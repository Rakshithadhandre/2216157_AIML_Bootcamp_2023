#drop- records and schema deleted permanantly
#step 1
import sqlite3

#combine step 2 & step 3
"BootCamp2023.db"
conn = sqlite3.connect("BootCamp2023.db")
print(conn)
'''
drop table table_name
'''
conn.execute("drop table participants")

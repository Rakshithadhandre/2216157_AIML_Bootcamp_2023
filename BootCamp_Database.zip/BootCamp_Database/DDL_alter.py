#alter- modifying the attributes
#step 1
import sqlite3

#combine step 2 & step 3
"BootCamp2023.db"
conn = sqlite3.connect("BootCamp2023.db")
print(conn)
#add a new column - mail_id into already existing table
'''
 alter table table_name column column_name datatype constraints
 '''
conn.execute('alter table participants add column mail_id text not null')
conn.commit()
conn.close()

'''
changing the datatype of already given attributes
remaining the attributes
alter table table_name rename column old_name to new_name
'''
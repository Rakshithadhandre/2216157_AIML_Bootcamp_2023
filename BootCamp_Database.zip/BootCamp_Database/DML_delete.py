#delete- records are deleted and table exists
#step 1
import sqlite3

#combine step 2 & step 3
"BootCamp2023.db"
conn = sqlite3.connect("BootCamp2023.db")
print(conn)
'''
delete records with G_id=2216154
delete from table_name where <<condition>>
'''
conn.execute("delete from participants where G_id='2216154'")
#conn.execute("delete from participants")
print(conn.total_changes)
conn.commit()
conn.close()
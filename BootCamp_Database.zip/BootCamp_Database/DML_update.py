#step 1
import sqlite3

#combine step 2 & step 3
"BootCamp2023.db"
conn = sqlite3.connect("BootCamp2023.db")
print(conn)

'''
update the name in the table
update table_name set column_name='new value' where <<condition>>
'''
conn.execute("update participants set name='Dhandre Rakshitha' where G_id=2216157 ")
conn.commit()
conn.close()
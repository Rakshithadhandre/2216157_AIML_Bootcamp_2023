#step 1
import sqlite3

#combine step 2 & step 3
"BootCamp2023.db"
conn = sqlite3.connect("BootCamp2023.db")
print(conn)
'''
insert into table_name values('','',.......)
'''
conn.execute("insert into participants values(2216157,'Rakshitha','CSE','Btech','dr@gmail.com')")
conn.execute("insert into participants values(2216156,'vyshu','CSE','Btech','vy@gmail.com')")
conn.execute("insert into participants values(2216155,'hafsa','ECE','Btech','h@gmail.com')")
conn.execute("insert into participants values(2216154,'lucky','ECE','Btech','l@gmail.com')")
conn.execute("insert into participants values(2216153,'rimsha','EEE','Btech','rr@gmail.com')")
print(conn.total_changes)
conn.commit()
conn.close()
#step 1
import sqlite3
#combine step 2 & step 3
"BootCamp2023.db"
conn = sqlite3.connect("BootCamp2023.db")
print(conn)
'''
describe table_name->Mysql
pragma table_info(table_name)->SQLite3
'''
#step 4
query='''
  pragma table_info(participants)  
'''
details=conn.execute(query)
print(details)
for i in details:
    print(i)
from Main_App.operations_pack import user_inputs as u
from Main_App.operations_pack import fetch_records as f
from Main_App.operations_pack import fetch_on_branch as b
from Main_App.operations_pack import update_name as un
while True:
  print('''
1.enter participants details
2.Fetch the participants records
3.Fetch the participants based on branch
4.update the name
''')
  print("choose any option from above menu")
  ch=int(input())
  if ch==1:
    print("do something")
    u.input_data()

  elif ch==2:
    f.get_record()
    print("----")

  elif ch==3:
    input_branch=input("ENter your branch in caps:")
    b.get_onbranch(input_branch)
    print("----")

  elif ch==4:
     id=input("Enter the g_id:")
     name=input("Enter the new name to be updated:")
     un.update(id.new_name)
     print("-----")
  else:
    break
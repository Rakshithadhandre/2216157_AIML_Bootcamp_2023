#sql commands
# data defination language-create,drop,alter,truncate
#Data Manipulation language-insert,update,delete
#Data control language-grant,revoke
#Transaction control- commit,Rollback, savepoint
#Data Querying language-select
#steps:
'''
1. import the module
2.Create a database
3.Establish the connection with the database
4.Perform operation-Creating a table in the database-Participants-writing the query
5.Execute the Query
'''
#step 1
import sqlite3
#combine step 2 & step 3
"BootCamp2023.db"
conn = sqlite3.connect("BootCamp2023.db")
print(conn)
'''
create table table_name(column_name1 datatype constraint(primary key key,not null, unique....),col2 datatype constraint,...)
'''
#step 4
query='''create table participants(G_id int primary key,name text not null,branch text not null,study text not null)'''

#step 5
conn.execute(query)
 #describe table_name
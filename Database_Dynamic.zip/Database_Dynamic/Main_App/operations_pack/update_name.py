import sqlite3
"Bootcamp2023.db"
conn=sqlite3.connect("Bootcamp2023.db")
def update(g_id,n):
   # update participants set name='Rakshu' where g_id=101
  query='''update participants set name="+n+" where g_id='"+g+'"+str(gid)+"' '''
  conn.execute(query)
  conn.commit()
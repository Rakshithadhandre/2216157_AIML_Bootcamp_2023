import sqlite3
"Bootcamp2023.db"
conn=sqlite3.connect("Bootcamp2023.db")
def get_onbranch(input_branch):
 #input_branch='CSE'

   conn.execute("select *from participants where branch='"+input_branch+"'")


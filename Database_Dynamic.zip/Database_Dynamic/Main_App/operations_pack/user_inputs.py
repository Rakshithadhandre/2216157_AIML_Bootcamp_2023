import sqlite3
conn=sqlite3.connect("Bootcamp2023.db")
def input_data():
    g_id=input("Enter the G_id:")
    name=input("Enter Name:")
    branch=input("Enter Branch:")
    study=input("Enter study:")
    data={} #data={'g_id:101,'name',:'Rakshitha,..}
    data['g_id']=g_id
    data['name']=name
    data['branch']=branch
    data['study']=study
    #insert into participants values(101,"Rakshitha","CSE","Btech")
    conn.execute('''
      insert into participants(g_id,name,branch,study) values(?,?,?,?)
    ''',(data.get("g_id"),data.get("name"),data.get("branch"),data.get("study")))
    conn.commit()
    print("Data inserted successfully")
    return data
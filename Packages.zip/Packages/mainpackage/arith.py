import mainpackage as mp
print(mp.x)
print(mp.mainpackage())
print("______________")
import mainpackage.subpack1 as ms1
print(ms1.sub1)
print(ms1.subpack1)
print("_____________")
from mainpackage.subpack1 import addsub as sa
print(sa.addn(5,5))
print(sa.subn(10,5))

import mainpackage.subpack2 as ms2
print(ms2.sub2)
print(ms2.subpack2)
print("__________")
from mainpackage.subpack2 import muldiv as md
print(md.muln(3,3))
print(md.divn(10,2))


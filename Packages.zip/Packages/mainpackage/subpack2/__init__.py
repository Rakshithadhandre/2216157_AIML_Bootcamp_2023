sub1="subpackage 2 demo"
def subpack2():
    return "subpackage 2 demonstration"